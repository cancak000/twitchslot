🎰 iV Slot の使い方

1. ngrok.exe を同じフォルダに入れてください
2. setting.env を開いて、あなたの Twitch 情報を記入してください
3. twitchslot_gui.exe をダブルクリック！
4. チャンネルポイントで「スロットを回す」などのリワードを作れば準備OK！

※注意
twitchslot_gui.exe と同じ場所に setting.env を置いてください。
ファイルがないと起動時にエラーになります。

⚠️ 初回起動時は Windows ファイアウォールに注意